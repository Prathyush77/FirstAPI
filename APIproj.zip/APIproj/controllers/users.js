
import { v4 as uuidv4 } from 'uuid';

let users = [];


export const getUsers = ( req, res ) =>
{
  res.send( users );
};

export const createUsers = ( req, res ) =>
{
  
  const user = ( req.body );
  const userId = uuidv4();

  const userWithId = { ...user, id: userId };
 
  users.push( userWithId );

  res.send( `User with the name ${ user.firstName } added to the database ` );
};

export const getUser = ( req, res ) => // /:id means when we add a ":" in the route that means it will take anythinig like for example localhost:5000/users/123 ==> here 123 is ID or we can also consider anythin like anyname like that. 
{
  const { id } = req.params;   // ==> basically req.params will get the value of /:id of the route.

  const findUser = users.find( ( user ) => user.id === id );

  res.send( findUser );
};

export const deleteUser = ( req, res ) =>
{
  const { id } = req.params;

  users = users.filter( ( user ) => user.id !== id );

  res.send( `user with the id ${ id } has been deleted from the database` );
};

export const updateUser = ( req, res ) =>
{
  const { id } = req.params;

  const { firstName, lastName, age } = req.body;

  const userToBeUpdated = users.find( ( user ) => user.id === id );

  if ( firstName )
  {
    userToBeUpdated.firstName = firstName;
  }
  if ( lastName )
  {
    userToBeUpdated.lastName = lastName;
  }
  if ( age )
  {
    userToBeUpdated.age = age;
  }
  
  res.send( `user with the id ${ id } has been updated` );

};